/* ISC license. */

/*
  This file is part of the utmps package.
  See https://skarnet.org/software/utmps/
*/

#ifndef UTMPX_H
#define UTMPX_H

#include <utmps/utmpx.h>

#endif
